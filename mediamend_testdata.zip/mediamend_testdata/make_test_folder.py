"""Generates a synthetic MediaMend test folder + ground_truth.csv. Run: python make_test_folder.py"""
import csv, shutil, subprocess, wave
from pathlib import Path
import cv2, numpy as np

OUT = Path(__file__).parent / "test_folder"
rng = np.random.default_rng(42)
rows = []
def log(path, mtype, truth, action, note=""):
    rows.append([Path(path).relative_to(OUT).as_posix(), mtype, truth, action, note])

def scene(seed, w=1280, h=720):
    r = np.random.default_rng(seed)
    img = np.full((h, w, 3), r.integers(60, 200, 3), np.uint8)
    for _ in range(40):
        c = tuple(int(v) for v in r.integers(0, 255, 3))
        p1 = (int(r.integers(0, w)), int(r.integers(0, h)))
        if r.random() < .5: cv2.rectangle(img, p1, (p1[0]+int(r.integers(30,200)), p1[1]+int(r.integers(30,200))), c, -1)
        else: cv2.circle(img, p1, int(r.integers(15, 100)), c, -1)
    for _ in range(25): cv2.putText(img, "MM"+str(int(r.integers(100,999))), (int(r.integers(0,w-150)), int(r.integers(40,h))), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255,255,255), 2)
    return img

# PHOTOS
for i in range(1, 6):
    p = OUT/"photos"/f"sharp_{i:02d}.jpg"; cv2.imwrite(str(p), scene(i)); log(p, "photo", "sharp", "keep")
for i in range(1, 5):
    p = OUT/"photos"/f"blurred_{i:02d}.jpg"; cv2.imwrite(str(p), cv2.GaussianBlur(scene(10+i), (0,0), 12)); log(p, "photo", "blurry", "review", "Gaussian blur sigma 12")
p = OUT/"photos"/"blurred_slight_01.jpg"; cv2.imwrite(str(p), cv2.GaussianBlur(scene(30), (0,0), 2.0)); log(p, "photo", "slightly_soft", "keep", "borderline; tests threshold")
for i in range(1, 3):
    p = OUT/"photos"/f"lowres_{i:02d}.jpg"; cv2.imwrite(str(p), cv2.resize(scene(40+i), (320,240))); log(p, "photo", "low_resolution", "review", "320x240")
p = OUT/"photos"/"dark_valid_01.jpg"; cv2.imwrite(str(p), (scene(50)*0.25).astype(np.uint8)); log(p, "photo", "dark_but_valid", "keep", "tests false positives")
p = OUT/"photos"/"must_keep_soft_candid.jpg"; cv2.imwrite(str(p), cv2.GaussianBlur(scene(60), (0,0), 7)); log(p, "photo", "must_keep", "keep", "Stand-in: replace with a real meaningful soft photo")
shutil.copy(OUT/"photos"/"sharp_02.jpg", OUT/"photos"/"sharp_02_copy.jpg"); log(OUT/"photos"/"sharp_02_copy.jpg", "photo", "exact_duplicate", "review", "copy of sharp_02.jpg")

# VIDEOS
def video(name, frame_fn, w=640, h=360, secs=4, fps=24):
    p = OUT/"videos"/name
    vw = cv2.VideoWriter(str(p), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in range(secs*fps): vw.write(frame_fn(f, w, h))
    vw.release(); return p
moving = lambda f,w,h: cv2.circle(cv2.resize(scene(70,w,h),(w,h)), (50+f*5 % (w-100), h//2), 40, (0,0,255), -1)
log(video("sharp_clip_01.mp4", moving), "video", "sharp", "keep")
log(video("blurred_clip_01.mp4", lambda f,w,h: cv2.GaussianBlur(moving(f,w,h),(0,0),12)), "video", "blurry", "review")
log(video("lowres_clip_01.mp4", lambda f,w,h: moving(f,w,h), w=160, h=120), "video", "low_resolution", "review", "160x120")
log(video("blank_clip_01.mp4", lambda f,w,h: np.zeros((h,w,3),np.uint8)), "video", "blank", "review", "all black")
log(video("few_blank_frames_01.mp4", lambda f,w,h: np.zeros((h,w,3),np.uint8) if 40<f<44 else moving(f,w,h)), "video", "few_blank_frames", "keep", "4 black frames only")

# AUDIO
def wav(name, samples, sr=16000):
    p = OUT/"audio"/name
    with wave.open(str(p), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(np.clip(samples, -32768, 32767).astype(np.int16).tobytes())
    return p
t = np.arange(16000*4)/16000
tone = lambda amp, f=220: amp*np.sin(2*np.pi*f*t)*(0.6+0.4*np.sin(2*np.pi*3*t))
log(wav("normal_tone_01.wav", tone(9000)), "audio", "normal", "keep", "synthetic tone, not real speech")
log(wav("quiet_tone_01.wav", tone(400)), "audio", "quiet_but_valid", "keep", "quiet signal; must not be auto-discarded")
log(wav("silence_01.wav", np.zeros(len(t))), "audio", "silent", "review")
log(wav("noise_only_01.wav", rng.normal(0, 12, len(t))), "audio", "near_silent_noise", "review", "very low noise floor")
mixed = tone(9000); mixed[16000*1:16000*3] = 0
log(wav("mixed_silence_speechlike_01.wav", mixed), "audio", "mixed", "keep", "2 s gap in 4 s")
log(wav("very_short_01.wav", tone(9000)[:400]), "audio", "very_short", "review", "25 ms; flagged as extremely short")

# OTHER
for name, mtype in [("empty_photo.jpg","photo"),("empty_audio.wav","audio"),("empty_video.mp4","video"),("empty_notes.txt","other")]:
    p = OUT/"other"/name; p.touch(); log(p, mtype, "zero_byte", "review")
p = OUT/"other"/"fake_image.jpg"; p.write_text("this is not an image"); log(p, "other", "corrupt", "review", "text renamed .jpg")
p = OUT/"other"/"notes.txt"; p.write_text("keep me"); log(p, "other", "unsupported_type", "keep")
p = wav("x.wav", tone(7000, 330)); p = p.rename(OUT/"other"/"naïve café ファイル 01.wav"); log(p, "audio", "tricky_filename", "keep", "tests non-ASCII/space paths")
shutil.copy(OUT/"audio"/"normal_tone_01.wav", OUT/"other"/"normal_tone_01_copy.wav"); log(OUT/"other"/"normal_tone_01_copy.wav", "audio", "exact_duplicate", "review", "copy of normal_tone_01.wav")

with open(OUT.parent/"ground_truth.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["file","media_type","ground_truth","expected_action","note"]); w.writerows(rows)
print(f"Created {len(rows)} files in {OUT}")
