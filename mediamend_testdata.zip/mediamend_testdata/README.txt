MediaMend test data (synthetic)
1. Scan the folder "test_folder" in MediaMend.
2. Compare the scan CSV against ground_truth.csv (expected_action: keep / review).
3. Re-run make_test_folder.py any time to recreate a fresh folder (it overwrites the files).
The files are synthetic. Add your own real photos/recordings (especially soft-but-meaningful photos and quiet speech) for a credible benchmark.
